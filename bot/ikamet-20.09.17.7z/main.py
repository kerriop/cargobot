import config, db, keyboards, recaptcha, userinfo, country
import telebot
import requests
import threading
import time

bot = telebot.TeleBot(config.token)

#Послать список полей и их номеров
#def showResetMessage(chatid):
    #bot.send_message(chatid, 'Имя = 0, Фамилия = 1, Дата рождения = 2, Имя отца = 3, Имя матери = 4, Пол = 5, Идентификационный номер по гражданству = 6, Страна = 7, Номер документа паспорта = 8', reply_markup=keyboards.reset)

#Послать юзеру сообщение проверки всех введенных данных
def showCheckMessage(chatid):
    ui = userinfo.getUser(chatid)
    bot.send_message(chatid, 'Имя: ' + str(ui.getName()), reply_markup=keyboards.zero)
    bot.send_message(chatid, 'Фамилия: ' + str(ui.getLastName()), reply_markup=keyboards.zero)
    bot.send_message(chatid, 'Дата рождения: ' + str(ui.getDate()), reply_markup=keyboards.zero)
    bot.send_message(chatid, 'Имя отца: ' + str(ui.getFName()), reply_markup=keyboards.zero)
    bot.send_message(chatid, 'Имя матери: ' + str(ui.getMName()), reply_markup=keyboards.zero)
    if ui.getSex() == 1:
        bot.send_message(chatid, 'Пол: женщина', reply_markup=keyboards.zero)
    elif ui.getSex() == 2:
        bot.send_message(chatid, 'Пол: мужчина', reply_markup=keyboards.zero)
    bot.send_message(chatid, 'Идентификационный номер по гражданству: ' + str(ui.getIdenNo()), reply_markup=keyboards.zero)
    bot.send_message(chatid, 'Страна: ' + str(country.cdict.get(ui.getCountry())), reply_markup=keyboards.zero)
    bot.send_message(chatid, 'Номер документа паспорта: ' + str(ui.getPassNo()), reply_markup=keyboards.checkData)

#Послать юзеру приглашение о вводе следующего текста/команды
def sendNextMessage(chatid):
    state = db.getState(chatid)
    if state == db.STATE_STARTED:
        bot.send_message(chatid, 'Введите свое имя:', reply_markup=keyboards.zero)
    elif state == db.STATE_INP_NAME:
        bot.send_message(chatid, 'Введите свою фамилию:', reply_markup=keyboards.zero)
    elif state == db.STATE_INP_LAST_NAME:
        bot.send_message(chatid, 'Введите свою дату рождения в формате "дд.мм.гггг":', reply_markup=keyboards.zero)
    elif state == db.STATE_INP_DATE:
        bot.send_message(chatid, 'Введите имя отца:', reply_markup=keyboards.zero)
    elif state == db.STATE_INP_FNAME:
        bot.send_message(chatid, 'Введите имя матери:', reply_markup=keyboards.zero)
    elif state == db.STATE_INP_MNAME:
        bot.send_message(chatid, 'Введите свой пол (м/ж):', reply_markup=keyboards.sex)
    elif state == db.STATE_INP_SEX:
        bot.send_message(chatid, 'Введите свой идентификационный номер по гражданству:', reply_markup=keyboards.zero)
    elif state == db.STATE_INP_IDENNO:
        bot.send_message(chatid, 'Введите страну, гражданином которой вы являетесь на данный момент:', reply_markup=keyboards.csel[0])
    elif state == db.STATE_INP_COUNTRY:
        bot.send_message(chatid, 'Введите номер документа паспорта:', reply_markup=keyboards.zero)
    elif state == db.STATE_INP_PASSNO:
        bot.send_message(chatid, 'Проверьте все введенные данные:', reply_markup=keyboards.zero)
        showCheckMessage(chatid)
    elif state == db.STATE_RESET_FIELD:
        bot.send_message(chatid, 'Выберите поле для изменения:', reply_markup=keyboards.reset)
        #showResetMessage(chatid)
    elif state == db.STATE_RESET_FIELD_CONTINUE:
        substate = db.getSubState(chatid)
        if substate == db.SUBSTATE_COUNTRY:
            bot.send_message(chatid, 'Введите новое значение поля:', reply_markup=keyboards.csel[0])
        else:
            bot.send_message(chatid, 'Введите новое значение поля:', reply_markup=keyboards.zero)

@bot.callback_query_handler(func=lambda c: True)
def countrySelectHandler(c):
    data = str(c.data)
    chatid = c.message.chat.id
    if db.getState(chatid) == db.STATE_PRE:
        bot.send_message(chatid, 'Ошибка! [Перезапуск...]')
        db.setState(chatid, db.STATE_STARTED)
        sendNextMessage(chatid)
        return
    if data.startswith('goto:'):
        npage = int(data[5:])
        bot.edit_message_reply_markup(
            chat_id=chatid,
            message_id=c.message.message_id,
            reply_markup=keyboards.csel[npage]
        )
    elif data == 'cd:ok':
        #Продолжаем регистрацию
        pass
    elif data == 'cd:no':
        db.setState(chatid, db.STATE_RESET_FIELD)
        sendNextMessage(chatid)
    elif data.startswith('reset:'):
        state = db.getState(chatid)
        if state != db.STATE_RESET_FIELD:
            return
        n = int(data[6:])
        if n >= 0 and n <= 8:
            db.setSubState(chatid, n)
            db.setState(chatid, db.STATE_RESET_FIELD_CONTINUE)
            sendNextMessage(chatid)
        else:
            bot.send_message(chatid, 'Внутренняя ошибка!', reply_markup=keyboards.zero)
            db.setState(chatid, db.STATE_INP_PASSNO)
            sendNextMessage(chatid)

    else:
        chatid = c.message.chat.id
        state = db.getState(chatid)
        if state != db.STATE_INP_IDENNO and (state != db.STATE_RESET_FIELD_CONTINUE and db.getSubState(chatid) != db.SUBSTATE_COUNTRY):
            return
        ui = userinfo.getUser(chatid)
        ui.setCountry(int(data))
        if state == db.STATE_INP_IDENNO:
            db.setState(chatid, db.STATE_INP_COUNTRY)
        else:
            db.setState(chatid, db.STATE_INP_PASSNO)
        sendNextMessage(chatid)

#Показать юзеру подсказку бота
def showHelp(chatid):
    bot.send_message(chatid, "Данный бот .... и .... а ещё очень крутой", reply_markup=keyboards.zero)

#Возврат юзера в состояние PRE, когда он должен ввести /start для начала
def resetState(chatid):
    db.setState(chatid, db.STATE_PRE)
    bot.send_message(chatid, 'Введите /start для начала', reply_markup=keyboards.start)

#Вызывается модулем капчи когда сервис решения решил капчу. Отправляем запрос на регистрацию (1 шаг)
def recaptchaCallback(chatid, response):
    print('Капча решена! chatid = ' + chatid + ', response = ' + response)

@bot.message_handler(commands=['help'])
def handle_help(message):
    showHelp(message.chat.id)

@bot.message_handler(commands=['start'])
def handle_start(message):
    if db.getState(message.chat.id) != -1:
        return
    db.setState(message.chat.id, db.STATE_STARTED)
    sendNextMessage(message.chat.id)

@bot.message_handler(content_types=["text"])
def handler(message):
    print('message: ' + message.text)
    chatid = message.chat.id
    if message.text == '':
        bot.send_message(chatid, 'Пожалуйста, введите текст..')
        return
    state = db.getState(chatid)
    ui = userinfo.getUser(chatid)
    if ui == None:
        userinfo.addUser(chatid)
        ui = userinfo.getUser(chatid)
    #Длинный if elif на все поля, помеченные для ввода
    if state == db.STATE_STARTED:
        ui.setName(message.text)
        db.setState(chatid, db.STATE_INP_NAME)
        sendNextMessage(chatid)
    elif state == db.STATE_INP_NAME:
        ui.setLastName(message.text)
        db.setState(chatid, db.STATE_INP_LAST_NAME)
        sendNextMessage(chatid)
    elif state == db.STATE_INP_LAST_NAME:
        ui.setDate(message.text)
        db.setState(chatid, db.STATE_INP_DATE)
        sendNextMessage(chatid)
    elif state == db.STATE_INP_DATE:
        ui.setFName(message.text)
        db.setState(chatid, db.STATE_INP_FNAME)
        sendNextMessage(chatid)
    elif state == db.STATE_INP_FNAME:
        ui.setMName(message.text)
        db.setState(chatid, db.STATE_INP_MNAME)
        sendNextMessage(chatid)
    elif state == db.STATE_INP_MNAME:
        if message.text == 'м':
            ui.setSex(2)
        elif message.text == 'ж':
            ui.setSex(1)
        else:
            bot.send_message(chatid, 'Пожалуйста, введите "м" или "ж":')
            return
        db.setState(chatid, db.STATE_INP_SEX)
        sendNextMessage(chatid)
    elif state == db.STATE_INP_SEX:
        ui.setIdenNo(message.text)
        db.setState(chatid, db.STATE_INP_IDENNO)
        sendNextMessage(chatid)
    elif state == db.STATE_INP_COUNTRY:
        ui.setPassNo(message.text)
        db.setState(chatid, db.STATE_INP_PASSNO)
        sendNextMessage(chatid)
    elif state == db.STATE_RESET_FIELD_CONTINUE:
        n = db.getSubState(chatid)
        if n < 0 or n > 8:
            bot.send_message(chatid, 'Внутренняя ошибка...', reply_markup=keyboards.zero)
            db.setState(chatid, db.STATE_INP_PASSNO)
            sendNextMessage(chatid)
            return
        if n == 0:
            ui.setName(message.text)
        elif n == 1:
            ui.setLastName(message.text)
        elif n == 2:
            ui.setDate(message.text)
        elif n == 3:
            ui.setFName(message.text)
        elif n == 4:
            ui.setMName(message.text)
        elif n == 5:
            if message.text == 'м':
                ui.setSex(2)
            elif message.text == 'ж':
                ui.setSex(1)
            else:
                bot.send_message(chatid, 'Пожалуйста, введите "м" или "ж":')
                return
        elif n == 6:
            ui.setIdenNo(message.text)
        #elif n == 7:
            #ui.setCountry(message.text)
        elif n == 8:
            ui.setPassNo(message.text)
        bot.send_message(chatid, 'Поле успешно изменено!', reply_markup=keyboards.zero)
        db.setState(chatid, db.STATE_INP_PASSNO)
        sendNextMessage(chatid)

    from pprint import pprint
    pprint(vars(ui))


    #bot.send_message(message.chat.id, message.text)

if __name__ == '__main__':
    print('Загрузка...')
    #session = requests.Session()
    #r = session.post('https://e-ikamet.goc.gov.tr/Ikamet/OnKayit')
    #print(r.text)
    print('Запрос списка стран...')
    country.init()
    print('Бот успешно загружен')
    bot.polling(none_stop=True)


#thread_test = threading.Thread(target=test, name="test")
#thread_test.start()