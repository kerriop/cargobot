import main

def solveRecaptcha(chatid, site_key):
    #убрать в релизе
    site_key = '6LfoNSMTAAAAAOaKqB6slHegPYgnkTVUDbiPgmwx'
    response = input('Введите recaptcha response: ')
    main.recaptchaCallback(chatid, response)

def solveRecaptcha2(chatid, site_key):
    site_key = '6LfoNSMTAAAAAOaKqB6slHegPYgnkTVUDbiPgmwx'
    response = input('Введите recaptcha response: ')
    main.recaptchaCallback(chatid, response)
    pass