class UserInfo(object):
    def __init__(self):
        self.name = ''
        self.lastName = ''
        self.date = ''
        self.fname = ''
        self.mname = ''
        self.sex = 0
        self.idenno = 0
        self.country = 0
        self.passno = 0

    def setName(self, name):
        self.name = name
    def setLastName(self, lastName):
        self.lastName = lastName
    def setDate(self, date):
        self.date = date
    def setFName(self, fname):
        self.fname = fname
    def setMName(self, mname):
        self.mname = mname
    def setSex(self, sex):
        self.sex = sex
    def setIdenNo(self, idenno):
        self.idenno = idenno
    def setCountry(self, country):
        self.country = country
    def setPassNo(self, passno):
        self.passno = passno

    def getName(self):
        return self.name
    def getLastName(self):
        return self.lastName
    def getDate(self):
        return self.date
    def getFName(self):
        return self.fname
    def getMName(self):
        return self.mname
    def getSex(self):
        return self.sex
    def getIdenNo(self):
        return self.idenno
    def getCountry(self):
        return self.country
    def getPassNo(self):
        return self.passno


users = {}

def addUser(chatid):
    users[chatid] = UserInfo()

def getUser(chatid):
    return users.get(chatid)