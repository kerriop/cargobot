from telebot import types

#Нулевая клавиатура
zero = types.ReplyKeyboardRemove()

#Клавиатура с командой /start
start = types.ReplyKeyboardMarkup()
start.row('/start')

#Клавиатура выбора пола
sex = types.ReplyKeyboardMarkup()
sex.row('м', 'ж')

#Клавиатура для этапа проверки данных
checkData = types.InlineKeyboardMarkup()
checkData.add(types.InlineKeyboardButton(text='Продолжить', callback_data='cd:ok'))
checkData.add(types.InlineKeyboardButton(text='Изменить поле', callback_data='cd:no'))

#Клавиатура для выбора поля, что нужно изменить
reset = types.InlineKeyboardMarkup()
reset.add(types.InlineKeyboardButton(text='Имя', callback_data='reset:0'))
reset.add(types.InlineKeyboardButton(text='Фамилия', callback_data='reset:1'))
reset.add(types.InlineKeyboardButton(text='Дата рождения', callback_data='reset:2'))
reset.add(types.InlineKeyboardButton(text='Имя отца', callback_data='reset:3'))
reset.add(types.InlineKeyboardButton(text='Имя матери', callback_data='reset:4'))
reset.add(types.InlineKeyboardButton(text='Пол', callback_data='reset:5'))
reset.add(types.InlineKeyboardButton(text='Идентификационный номер по гражданству', callback_data='reset:6'))
reset.add(types.InlineKeyboardButton(text='Страна', callback_data='reset:7'))
reset.add(types.InlineKeyboardButton(text='Номер документа паспорта', callback_data='reset:8'))

#Клавиатура с выбором стран
csel = []
cselLen = 0