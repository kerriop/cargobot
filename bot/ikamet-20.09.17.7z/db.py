#До начала работы бота (или после конца и до следующего начала)
STATE_PRE = -1
#После ввода команды /start. Спрашиваем все необходимые данные
STATE_STARTED = 0
#После ввода имени
STATE_INP_NAME = 1
#После ввода фамилии
STATE_INP_LAST_NAME = 2
#После ввода даты
STATE_INP_DATE = 3
#После ввода имени отца
STATE_INP_FNAME = 4
#После ввода имени матери
STATE_INP_MNAME = 5
#После ввода пола
STATE_INP_SEX = 6
#После ввода идентиф. номера по гражданству
STATE_INP_IDENNO = 7
#После ввода гражданства
STATE_INP_COUNTRY = 8
#После ввода номера документа паспорта, готовность к email и капче
STATE_INP_PASSNO = 9
#Состояние выбора поля для изменения
STATE_RESET_FIELD = 10
#Состояние самого изменения поля
STATE_RESET_FIELD_CONTINUE = 11

SUBSTATE_NAME = 0
SUBSTATE_LAST_NAME = 1
SUBSTATE_DATE = 2
SUBSTATE_FNAME = 3
SUBSTATE_MNAME = 4
SUBSTATE_SEX = 5
SUBSTATE_IDENNO = 6
SUBSTATE_COUNTRY = 7
SUBSTATE_PASSNO = 8

b = {}
sub = {}

def setState(chatid, state):
    b[chatid] = state

def getState(chatid):
    state = b.get(chatid)
    if state == None:
        return -1
    else:
        return state

def setSubState(chatid, subState):
    sub[chatid] = subState

def getSubState(chatid):
    subState = sub.get(chatid)
    if subState == None:
        return -1
    else:
        return subState