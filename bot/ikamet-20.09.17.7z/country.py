import requests
import json
import keyboards
from telebot import types

blockSize = 20
session = requests.Session()
cookie = None
cdict = {}

def __process(page, maxPage):
    skip = page * blockSize
    r = session.get("https://e-ikamet.goc.gov.tr/Parametre/GetVirtualizedAutoComplete?name=ULKETURKIYEHARIC&take="+str(blockSize)+"&skip="+str(skip)+"&page="+str(page)+"&pageSize="+str(blockSize), cookies=cookie)
    j = json.loads(r.text)
    data = j['data']
    keyb = types.InlineKeyboardMarkup()
    keyboards.csel.append(keyb)
    keyboards.cselLen = keyboards.cselLen + 1
    for d in data:
        cdict[d['kod']] = str(d['aciklama'])
        keyb.add(types.InlineKeyboardButton(text=d['aciklama'], callback_data=str(d['kod'])))
    if page != 0:
        keyb.add(types.InlineKeyboardButton(text='<---', callback_data='goto:' + str(page - 1)))
    if page < maxPage - 1:
        keyb.add(types.InlineKeyboardButton(text='--->', callback_data='goto:' + str(page + 1)))
    total = int(j['total'])
    return total

def init():
    global cookie
    session = requests.Session()
    session.get("https://e-ikamet.goc.gov.tr/Language/SetLanguage?langtag=ru")
    cookie = session.cookies.get_dict()

    i = 0
    total = __process(i, 2)
    i = i + 1
    maxPage = int(total / blockSize) + 1
    while i < maxPage:
        __process(i, maxPage)
        i = i + 1
